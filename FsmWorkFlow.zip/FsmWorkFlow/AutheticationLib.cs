﻿namespace FsmWorkFlow;

public class AuthenticationLib : IAuthenticate
{
    public string? IsAuthenticatedUser(string userName, string password)
    {
        if (!string.IsNullOrWhiteSpace(userName)
            && string.Compare(userName, password) == 0)
            return userName.ToLower();
        else return null;
    }
}
