﻿namespace FsmWorkFlow;

public class ShowingOutcome : IFsmState
{
    public FsmStateMachine Fsm { get; init; }
    public ShowingOutcome(FsmStateMachine fsm) => Fsm = fsm;

    public void Authenticate(string user, string password) { }

    public void Start() { }

    public void SubmitTestRunForm() { }

    public void Terminate() => Fsm.CurrState = null;
}
