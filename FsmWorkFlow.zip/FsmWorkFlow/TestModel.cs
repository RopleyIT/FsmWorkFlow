﻿namespace FsmWorkFlow;

public class TestModel
{
    public long? TestRunId { get; set; }
    public string? Analyte { get; set; }
    public double? Concentration { get; set; }
    public string? Units { get; set; }
    public string? FirstApprover { get; set; }
    public string? SecondApprover { get; set; }
    public string? ValidationError { get; set; }
    public string? CompletionResult { get; set; }

    public bool Validate()
    {
        if (TestRunId == null)
        {
            ValidationError = "Missing TestRunId";
            return false;
        }
        return true;
    }

    public void GenerateTestOutput()
    {
        // Place holder for completing the analysis
        CompletionResult = "Displaying test output!";
    }
}
