﻿namespace FsmWorkFlow;

public class FsmStateMachine : IFsmState
{
    public TestModel TestModel { get; set; }
    internal IAuthenticate AuthLib { get; init; }
    internal IFsmState FillingFormState { get; init; }
    internal IFsmState AuthenticatingFirstSigner { get; init; }
    internal IFsmState AuthenticatingSecondSigner { get; init; }
    internal IFsmState ShowingOutcome { get; init; }

    // Testing only
    public IFsmState? CurrState { get; set; }

    public FsmStateMachine(IAuthenticate authLib)
    {
        // Handle dependency injections
        AuthLib = authLib;

        // Create all the state objects here
        FillingFormState = new FillingFormState(this);
        AuthenticatingFirstSigner = new AuthenticatingFirstSigner(this);
        AuthenticatingSecondSigner = new AuthenticatingSecondSigner(this);
        ShowingOutcome = new ShowingOutcome(this);

        // Set the starting state for the machine
        CurrState = FillingFormState;

        // Fire the start event to initialise the empty form
        TestModel = new();

        // In case some other initialisation takes place
        CurrState.Start();
    }

    public void Authenticate(string user, string password)
        => CurrState?.Authenticate(user, password);

    public void Start() => CurrState?.Start();

    public void SubmitTestRunForm()
        => CurrState?.SubmitTestRunForm();

    public void Terminate() => CurrState?.Terminate();

    /// <summary>
    /// Here to satisfy the IFsmState interface requirements
    /// </summary>

    public FsmStateMachine Fsm => this;
}
